=================================
Welcome to Blessed documentation!
=================================

Contents:

.. toctree::
   :maxdepth: 3
   :glob:

   intro
   overview
   examples
   further
   pains
   api
   contributing
   history

=======
Indexes
=======

* :ref:`genindex`
* :ref:`modindex`
