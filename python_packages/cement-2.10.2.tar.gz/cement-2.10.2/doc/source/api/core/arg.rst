.. _cement.core.arg:

:mod:`cement.core.arg`
----------------------

.. automodule:: cement.core.arg
    :members:
    :private-members:
    :show-inheritance:
