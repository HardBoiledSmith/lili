.. _cement.core.config:

:mod:`cement.core.config`
--------------------------

.. automodule:: cement.core.config
    :members:
    :private-members:
    :show-inheritance: