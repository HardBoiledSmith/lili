.. _cement.core.exc:
    
:mod:`cement.core.exc`
-----------------------

.. automodule:: cement.core.exc
    :members:   
    :private-members:
    :show-inheritance: