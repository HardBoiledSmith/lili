.. _cement.core.extension:

:mod:`cement.core.extension`
-----------------------------

.. automodule:: cement.core.extension
    :members:    
    :private-members:
    :show-inheritance: