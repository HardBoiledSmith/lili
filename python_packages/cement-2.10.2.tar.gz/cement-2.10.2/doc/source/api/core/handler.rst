.. _cement.core.handler:
    
:mod:`cement.core.handler`
---------------------------

.. automodule:: cement.core.handler
    :members:    
    :private-members:
    :show-inheritance: