.. _cement.core.hook:

:mod:`cement.core.hook`
------------------------

.. automodule:: cement.core.hook
    :members:   
    :private-members:
    :show-inheritance: