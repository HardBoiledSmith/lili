.. _cement.core.plugin:

:mod:`cement.core.plugin`
--------------------------

.. automodule:: cement.core.plugin
    :members:   
    :private-members:
    :show-inheritance: