.. _cement.ext.ext_alarm:

:mod:`cement.ext.ext_alarm`
---------------------------

.. automodule:: cement.ext.ext_alarm
    :members:   
    :private-members:
    :show-inheritance:
