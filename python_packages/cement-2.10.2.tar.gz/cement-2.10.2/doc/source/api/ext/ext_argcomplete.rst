.. _cement.ext.ext_argcomplete:

:mod:`cement.ext.ext_argcomplete`
---------------------------------

.. automodule:: cement.ext.ext_argcomplete
    :members:
    :private-members:
    :show-inheritance:
