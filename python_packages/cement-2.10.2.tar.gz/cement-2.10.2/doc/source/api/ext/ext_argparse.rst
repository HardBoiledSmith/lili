.. _cement.ext.ext_argparse:

:mod:`cement.ext.ext_argparse`
-------------------------------

.. automodule:: cement.ext.ext_argparse
    :members:
    :private-members:
    :show-inheritance:
