.. _cement.ext.ext_configparser:

:mod:`cement.ext.ext_configparser`
-----------------------------------

.. automodule:: cement.ext.ext_configparser
    :members:   
    :private-members:
    :show-inheritance:
