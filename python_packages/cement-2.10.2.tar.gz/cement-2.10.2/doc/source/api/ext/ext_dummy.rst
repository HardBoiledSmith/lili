.. _cement.ext.ext_dummy:

:mod:`cement.ext.ext_dummy`
------------------------------------

.. automodule:: cement.ext.ext_dummy
    :members:   
    :private-members:
    :show-inheritance:
