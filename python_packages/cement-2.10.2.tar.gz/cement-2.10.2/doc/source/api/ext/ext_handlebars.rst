.. _cement.ext.ext_handlebars:

:mod:`cement.ext.ext_handlebars`
--------------------------------

.. automodule:: cement.ext.ext_handlebars
    :members:   
    :private-members:
    :show-inheritance:
