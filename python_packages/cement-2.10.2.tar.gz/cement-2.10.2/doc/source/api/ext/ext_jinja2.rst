.. _cement.ext.ext_jinja2:

:mod:`cement.ext.ext_jinja2`
----------------------------

.. automodule:: cement.ext.ext_jinja2
    :members:   
    :private-members:
    :show-inheritance:
