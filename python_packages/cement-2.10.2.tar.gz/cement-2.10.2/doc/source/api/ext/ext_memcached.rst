.. _cement.ext.ext_memcached:

:mod:`cement.ext.ext_memcached`
-------------------------------

.. automodule:: cement.ext.ext_memcached
    :members:   
    :private-members:
    :show-inheritance:
