.. _cement.ext.ext_plugin:

:mod:`cement.ext.ext_plugin`
-----------------------------

.. automodule:: cement.ext.ext_plugin
    :members:   
    :private-members:
    :show-inheritance:
