.. _cement.ext.ext_redis:

:mod:`cement.ext.ext_redis`
---------------------------

.. automodule:: cement.ext.ext_redis
    :members:   
    :private-members:
    :show-inheritance:
