.. _cement.ext.ext_tabulate:

:mod:`cement.ext.ext_tabulate`
------------------------------

.. automodule:: cement.ext.ext_tabulate
    :members:   
    :private-members:
    :show-inheritance:
