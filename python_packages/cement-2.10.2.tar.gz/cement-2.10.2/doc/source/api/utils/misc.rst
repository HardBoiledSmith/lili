.. _cement.utils.misc:

:mod:`cement.utils.misc`
------------------------

.. automodule:: cement.utils.misc
    :members:   
    :private-members:
    :show-inheritance:
