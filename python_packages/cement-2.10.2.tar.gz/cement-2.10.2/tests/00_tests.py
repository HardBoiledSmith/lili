
import os
os.environ['CEMENT_TEST'] = '1'
