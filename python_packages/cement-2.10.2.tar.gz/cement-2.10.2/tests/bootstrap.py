"""Test bootstrap file"""


def load(app):
    pass
