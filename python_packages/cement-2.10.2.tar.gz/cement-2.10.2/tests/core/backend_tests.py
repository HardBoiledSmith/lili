"""Tests for cement.core.backend."""

from cement.core import backend