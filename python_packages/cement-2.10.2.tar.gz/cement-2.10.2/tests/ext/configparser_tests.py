
from cement.utils import test
from cement.utils.misc import init_defaults


@test.attr('core')
class ConfigParserConfigHandlerTestCase(test.CementExtTestCase):
    pass
